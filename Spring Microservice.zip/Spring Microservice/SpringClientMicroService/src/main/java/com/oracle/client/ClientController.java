package com.oracle.client;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import com.oracle.client.Employee;

@RestController
@RequestMapping("client")
public class ClientController {

	protected RestTemplate restTemplate;
	@Autowired
	private EurekaClient discoveryClient;

	public String serviceUrl() {
	    InstanceInfo instance = 
	    		discoveryClient.getNextServerFromEureka("EMPLOYEE-SERVICE", false);
	  
	    return instance.getHomePageUrl();
	}
	
	@GetMapping("retrieveemployee")
	public ResponseEntity<Employee> retrieveEmployee(){
		restTemplate=new RestTemplate();
		//Based on discovery from Eureka Server
		Employee employee=restTemplate.
				getForObject(serviceUrl()+"/employee/allemployees", Employee.class);
	    //Hard coded url which may change
		//Employee employee=restTemplate.getForObject("http://localhost:8088/employee/allemployees", Employee.class);
		ResponseEntity<Employee> response=new ResponseEntity<Employee>(employee,
				HttpStatus.OK);
		return response;
	

}
}

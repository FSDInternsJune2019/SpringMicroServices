package com.oracle.microservice;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("employee")
public class EmployeeController {
	public EmployeeController(){
		System.out.println("--Employee Controller constructor--");
	}
	
	@GetMapping("allemployees")
	public ResponseEntity<Employee> retrieveAllEmployee(){
		
		List<Employee> empList=new ArrayList<Employee>();
		
		Employee e1=new Employee();
		e1.setEmpId(101);
		e1.setEmpName("sabbir");
		e1.setEmpSalary(34000);
		e1.setEmpDesignation("Developer");
		ResponseEntity<Employee> response=new ResponseEntity<Employee>
		(e1,HttpStatus.OK);
		return response;
	}
	
	
	
	

}
